

library(tidyverse)
# Multiple Regression Examples using R code.

# Example 1
# We use the Income Data to execute multiple regression procedures


#read_csv("IncomeData.csv")->ID
#ID

# Lets input the data directly instead of importing

WorkExperience <- c(21,14,4,16,12,20,25,8,24,28,4,15)
WorkExperience
LevelofEducation <- c(6,3,8,8,4,4,1,3,12,9,11,4)
LevelofEducation
AnnualIncomeTD <- c(34.7,17.9,22.7,63.1,33,41.4,20.7,14.6,97.3,72.1,
                    49.1,52)
AnnualIncomeTD


data.frame(WorkExperience,LevelofEducation,AnnualIncomeTD) ->IDD
IDD


# Let's look at a matrix of scatter plots so that we can visualize
# behaviour relationships between the variables.
pairs(IDD[1 : 3])

# According to the scatterplot(2nd col/3rd row) The independent
# variable LevelofEducation is strongly correlated with the dependent
# variable AnnualIncomeTD That is good for LevelofEducation
# is correlated with AnnualIncome.

# According to the scatterplot(1st col/3rd row) The independent
# variable WorkExperience is notstrongly correlated with the 
# dependent variable AnnualIncome.  This is possibly a problem for 
# using WorkExperience in the model.


# According to the scatterplot(1st col/2nd row) The independent
# variable WorkExperience is not strongly correlated with the 
# independent variable LevelofEducation.  Hence we do not have a
# Multicollearity problem involving the variables WorkExperience and
# LevelofEducation.


# We now look at a correlation matrix to also find out what linear
# relationships exists between the variables.  This representation
# uses correlation coefficients.

cor(IDD)

# Note that the correlation coefficient for WorkExperience and Level
# ofEducation is very close to 0. Again, this points to no correlation
# between the independent variables; no Multicollinearity.


# Now we generate a potential model using both independent variables
# Height and Weight.

lm(AnnualIncomeTD ~ WorkExperience + LevelofEducation , IDD )-> model
  model

# Our multiregression model is ;
  
# AnnualIncomeTD = -15.248 + 1.545WorkExperience + 
# 5.568LevelofEducation
  

# We now execute the summary function on our model to investigate and
# interpret variable p values, the model p value , and other 
# statistical indicators. We also produce confidence intervals for
# the coefficients

summary(model)
confint(model, con.level = .95)



# Example 2

Height<- c(30,26.25,25,27,27.5,24.5,27.75,25,28,27.25,26,27.25,27,
           28.25)
Height
Weight<- c(339,267,289,332,272,214,311,259,298,288,277,292,302,336)
Weight
HeadCircumference <- c(47,42,43,44.5,44,40.5,44,41.5,46,44,44,44.5,
                       42.5,44.5)
HeadCircumference

data.frame(Height,Weight,HeadCircumference) ->HC
HC

# Let's look at a matrix of scatter plots so that we can visualize
# behaviour relationships between the variables.
pairs(HC[1:3])

# According to the scatterplot(2nd col/3rd row) The independent
# variable Weight is strongly correlated with the dependent variable
# HeadCircumfrence.  That is good for Weight is correlated with 
# Headcircumference.

# According to the scatterplot(1st col/3rd row) The independent
# variable Height is strongly correlated with the dependent variable
# HeadCircumfrence.  That is good for Height is correlated with
# Headcircumference.

# According to the scatterplot(1st col/2nd row) The independent
# variable Height is strongly correlated with the independent variable
# Weight. That is not good for Height is strongly correlated with
# Weight.  We have Multilinearity for Weight and Height.


# We now look at a correlation matrix to also find out what linear
# relationships exists between the variables.  This representation
# uses correlation coefficients.
cor(HC)

# Note the high correlation coefficient value for the variables Height
# and Weight.   .7847652.  This tells us that there is a potential
# problem with usage of both variables.


# Now we generate a potential model using both independent variables
# Height and Weight.

lm(HeadCircumference ~ Height + Weight , HC )-> model1
model1

# Our multiple regression model is;
# Headcircumference = .78634Height + .01281Weight



# We now execute the summary function on our model to investigate and
# interpret variable p values, the model p value , and other 
# statistical indicators.

summary(model1)
confint(model1, con.level = .95)

# Note that the p value for the variable Weight is above .05.  Is the
# variable Weight contributing significantly to the model?
# The answer is NO!! 

# Example 3

# Import the Miles per Gallon  data
#library(tidyverse)
#read_csv("MilesperGallonData.csv")
#Assign the data a variable

#read_csv("MilesperGallonData.csv") -> milpgal
#milpgal

# We will enter the miles per gallon directly instead of importing.

EngineSize <- c(2.4,2.4,2.5,3.5,2.8,3.5,3.5,3,3.6,2.4,3.3,2.5,3.5)
EngineSize

CurbWeight <- c(3289,3263,3230,3580,3175,3643,3497,3340,3861,3287,
                3629,3270,3292)
CurbWeight

Horsepower <- c(177,158,170,272,255,263,306,230,263,173,234,170,270)

Horsepower

MilesperGallon <- c(24,25,24,22,18,22,20,21,19,24,21,22,22)
MilesperGallon


data_frame(EngineSize, CurbWeight, Horsepower, MilesperGallon)-> mpgal
mpgal


# Produce a full multiple regression model, using all independet 
# variables  (MileperGallon is the dependent variable)

lm(MilesperGallon ~ EngineSize + CurbWeight + Horsepower ,  
   mpgal) -> x
x
 
summary(x)

# Is the full model ssignificant? 
# Yes, because the F statistic p value (.2585) is < .05

# Can we reject the null hypothesis that the coefficient for
# Horsepower is equal to 0 ?
# Yes, because the p value (.03401) is < than 0.

# Why are the variables EngineSize and Curbweight potential problems
# for the full regression model ?
# Answer;  Their p values are greater than .05.

# How can the overall model be significant at the .05 level, but the
# indivdual variables EngineSize and Curbweight be insignificant at
# at the .05 level ?
# Answer;  EngineSize and Curbweight maybe highly correlated. We may
# have collinearity problems with those variables..Let's find out.

cor(mpgal)

# Yes, EngineSize and Curbweight are highly correlated. 
# Also, Horsepower and Enginesize and Horsepower are highly 
# correlated.
# And also note that neither Enginesize or Curbweight are correlated
# to the dependent variable MilesperGallon. 

# Which model is better ? 
# The full model or a models minus Enginesize or Curbweight or both.
# We will keep Horsepower since it is not highly correlated to other
# independent variables.

# Lets produce a model that does not have Enginesize.
  
lm(MilesperGallon ~  CurbWeight + Horsepower ,  
   mpgal) -> y
y

summary(y)

# Lets produce a model that does not have Curbweight.

lm(MilesperGallon ~ EngineSize + Horsepower ,  mpgal) -> z
z

summary(z)

# Lets produce a model that does not have Curbweight or EngineSize.

lm(MilesperGallon ~ Horsepower ,  mpgal) -> zz
zz

summary(zz)

# Regression Model Comparison Summary

# Since the variiables EngineSize and Curbeweight were highly 
# correlated to each other and neither was highly correlated to the
# independent variable, they should be dropped from the model. Note
# that the single independent variable model has an overall
# significance level (.004209) which is lower than all four possible
# models.

# Finally, a residual analysis is a good way to determine if a model
# is stable.  This can be done of course in the early stages of the
# model analysis.  If the residuals are normally distributed, then
# you have do not have major problems with the model.  We have decided
# that the model with one independent variable is the best model. We
# will investigate by creating a normalprobability plot for model
# zz.

# Step 1.  Lets get the residuals for model  zz  
resid(zz)
# Step 2.  Now lets produce the normal qq plot to find out if our
# residuals are normal.
qqnorm(resid(zz))
qqline(resid(zz))

# Yes the residuals seem to be mostly normal for the data points are
# gnerally close to the line.
# Hence this is additional eveidence that the zz model is stable.



q()
y
