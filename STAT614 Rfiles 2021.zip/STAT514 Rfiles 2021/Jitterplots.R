

library(tidyverse)
library(ggplot2)

geom_jitter(data = NULL, width = NULL, height = NULL)


# Create R ggplot Jittering

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight)) + 
  geom_jitter()


# Change Color of a R ggplot Jitter

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight)) + 
  geom_jitter(aes(colour = Diet))


# Position adjustment of a R ggplot Jitter

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight)) + 
  geom_jitter(position = position_jitter(0.5), 
              aes(colour = Diet))

# Change Shape & Size of a Point in a R ggplot Jitter

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight)) + 
  geom_jitter(position = position_jitter(0.5), 
              aes(colour = Diet),
              cex = 1.8, shape = 8)


# Change Width & Height of a R ggplot Jitter

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight)) + 
  geom_jitter(aes(colour = Diet),
              width = 1.4, height = 500)


# Add Mean & Median to R ggplot Jitter

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight)) + 
  geom_jitter(position = position_jitter(0.5), aes(colour = Diet)) +
  stat_summary(fun.y = "mean", geom = "point", 
               shape = 8, size = 3, color = "darkorchid4" ) +
  stat_summary(fun.y = "median", geom = "point", 
               shape = 2, size = 3, color = "mediumvioletred")

# Add Boxplot to R ggplot Jitter

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight)) + 
  geom_boxplot() +
  geom_jitter(position = position_jitter(0.5), aes(colour = Diet)) 


names(ChickWeight$Diet)

ggplot(ChickWeight, aes(x = Diet, y = weight)) + 
  geom_boxplot() +
  geom_jitter(position = position_jitter(0.5), aes(colour = Diet)) +
  coord_flip()



# Add Violin Plot to R ggplot Jitter

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight, color = Diet)) + 
  geom_violin(fill = "blue") +
  geom_jitter(position = position_jitter(0.3)) 


# Alter Legend Position in R ggplot Jitter

# Importing the ggplot2 library
library(ggplot2)

# Creating basic Jitter
ggplot(ChickWeight, aes(x = Diet, y = weight, color = Diet)) + 
  geom_violin(fill = "midnightblue") +
  geom_jitter(position = position_jitter(0.2)) +
  theme(legend.position = "right") +
  labs(title = "GGPLOT JITTER" , x = "Chick Diet" ,  y = "Weight")


q()
y