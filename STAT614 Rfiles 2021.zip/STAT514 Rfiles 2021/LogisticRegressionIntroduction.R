



# LOGISTIC REGRESSION  (Introduction)
#      * Used when the response variable is a binary categorical variable (1 or 0)
#      * Based on probability and odds (You will answer questions concerning probability or
#     odds)
#      * Formulas used for to process Logistic Regression
#      1) ln(P/(1 - P) =  B(0) + B(1)X(1) + B(2)X(2) + ... + B(k)X(k)
#      2) P =  (e^(B(0) + B(1)X(1) + B(2)X(2) + ... + B(k)X(k)) /
#              (1 + e^( B(0) + B(1)X(1) + B(2)X(2) + ... + B(k)X(k))

tribble(~EntranceExamScore,  ~GPA,   ~ADMIT,
        72,               3.2,       0,
        81,               3.4,       0,
        67,               2.7,       0,
        77,               2.8,       0,
        87,               3.3,       1,         
        79,               3.8,       1,
        85,               2.7,       0,
        76,               2.5,       0,
        90,               3.1,       1,
        77,               2.6,       0,
        64,               2.4,       0,
        70,               2.75,      0,
        88,               3.0,       1,
        79,               3.55,      0,
        72,               2.8,       0,
        80,               3.3,       1,
        80,               2.4,       0,
        76,               3.0,       0,
        76,               2.75,      0,
        89,               2.8,       1,
        93,               3.3,       1,
        88,               3.2,       1,
        83,               3.5,       0
) -> ps
ps


glm(ADMIT ~ EntranceExamScore + GPA, family = "binomial",  data = ps) -> logisticps
logisticps

summary(logisticps)


#   ln(P/(1 - P) = -59.1733 + .5536EntranceExamScore + 4.1010GPA  


# Example
#   Now use your model to find the probability that a student will be admitted if she has a 
#   GPA of 2.85 and an Entrance exam score of 83.

# ln(P/(1 - P) =   -59.1733 + .5536(83) + 4.1010(2.85)
# ln(P/(1 - P) = -1.53665
# e^(ln(P/(1 - P)) =e^(-1.53665)
#     P/(1 - P) = .2151005
# solve for P
#  P = .2151005(1 - P)
#  P =  .2151005 - .2151005P
#  1.2151005P = .2151005
#         P =  .2151005/ 1.2151005
#         P = .17538  (rounded to five digits)
# Hence the probability is approximately .18

# Find the odds that the student will be admitted.
# P/(1-P)  =  .18/.82 = 18/82 = 9/41 or 9 : 41 or 9 to 41
