# Day One lab and practice key

#1
sqrt(63504)
63504**.5
63504^.5
#2
log10(45000)
#3
log(23.05)
#4
15:1
#5
mean(c(3,5,7,11,13,17))
#6
Z <- list(121, "atom", TRUE, .333, "earth")
Z

str(Z)

#7
round(17.3838, digit = 2)

#8
7*(5^3 - 2)^2

#9  

Zscorefunctiion <-  function(Mean, ObsV, sd)
{(ObsV - Mean)/sd
  return((ObsV - Mean)/sd)
}

Zscorefunctiion(23.54, 25.77, 2.442)

#10
round(
  Zscorefunctiion(23.54, 25.77, 2.442), digit = 1)
