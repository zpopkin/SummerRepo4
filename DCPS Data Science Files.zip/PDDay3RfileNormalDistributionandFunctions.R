
# R Coding for a Normal Distribution)
# An Introduction to Writing Functions


library(tidyverse)
#install.packages("Sleuth3")
library(Sleuth3)
library(broom)

# Let's generate a normal curve
x <- seq(-4, 4, length=1000)
y <- dnorm(x, mean=0, sd=1)
plot(x, y, type="l", lwd= 2)

# Finding Heights of a Normal Curve for designated values. (Use the dnorm function)

# 1 Find the height of the normal curve for an x value of -2

dnorm(x = -2, mean = 0, sd = 1) # the function dnorm produces the height of the
# the normal curve at a specified value.

# note that the symmetric property of the normal curve will give the same
# answer for an x value of 2.

dnorm(x = 2, mean = 0, sd = 1)


# 2 The rnorm function will randomly produce a specified number of normally distri-
# buted values that are randomly selected, given a mean and a standard deviation.

rnorm(n = 550, mean = 1, sd = 1) 

rnorm(n = 200, mean = 3, sd = 2.75)



# 3 The pnorm function will produce the area under the normal curve that is to the
# left of a given value.  This area is also a probability designation.

pnorm(q = 2, mean = 1, sd = 1)

# 3a For a normal distribution with a mean of 40 and a standard deviation of 5,
#    Find the area under the curve that is less than or equal to 43.
pnorm(q = 43, mean = 40, sd = 5)

# 3b Test scores are normally distributed with a mean of 70 and a standard
# deviation of 4.75. Find the probability that a student will score above 79 on
# the test.
pnorm(q = 79, mean = 70, sd = 4.75) # this will give the probability of getting a
# score that is below 79.

# Now subtract your answer from 1

1 - 0.9709364

# 3c Test scores are normally distributed with a mean of 70 and a standard
# deviation of 4.75. Find the probability that a student will score between 65 and
# 85 on the test.

#  Step 1  Find the probability for getting less than the upper bound
pnorm(q = 85, mean = 70, sd = 4.75)     # 0.9992054

#  Step 2  Find the probability for getting less than the lower bound
pnorm(q = 65, mean = 70, sd = 4.75)    # 0.1462549

#  Step 3  Subtract!!  Step 1 answer -  Step 2 answer  0.9992054 - 0.1462549

0.9992054 - 0.1462549


# 4 qnorm is called the quantile function. Given a mean and a standard deviation,
# it will give a value that an indicated probability (area) is to the left of.
qnorm(p = 0.8413, mean = 60, sd = 5)

#4a  Test scores are normally distributed with a mean of 75 and a standard 
# deviation of 3.25. 65% of the scores are less than what score?
qnorm(p = 0.65, mean = 75, sd = 3.25)

#4b  Test scores are normally distributed with a mean of 75 and a standard 
# deviation of 3.25. 65% of the scores are greater than what score?

# If 65% is greater than the unkown score, the 35% is less than the unknown score.

qnorm(p = 0.35, mean = 75, sd = 3.25)



# An Introduction to Functions
# DS 413/613
# Functions  Chapters 15 and 17
library(tidyverse)

# A function is a structured and sequenced set of commands that process input
# values to produce output values efficiently. A function reduces repetitive
# calculations that often result in mistakes, errors, and unneeded work.

# Consider the task of calculating the volume of twenty cylinders with the given
# dimensions:
# Cylinder1  r = 4, h = 6      V = pi(4^2)(6)
# Cylinder2  r = 3, h = 10     V = pi(3^2)(10)
# Cylinder3  r = 2.5, h = 5    V = pi(2.5^2)(5)
# Cylinder4  r = 12, h = 4     V = pi(12^2)(4)
# Cylinder5  r = 20, h = 14    V = pi(20^2)(16)
#            .
#            .
#            .
# Cylinder20 r = 12.25, h = 9  V = pi(12.25)(9)

# The formula V = pi(r^2)h would have to be applied correctly 20 times, if you
# are to do these manually; one at a time.  There is certainly a high risk for
# some type of errors i.e. data entry or misuse of the formula for a problem.

# Were any errors committed in the executions above ?

# We now use a function for this problem to reduce repetitive calculations and
# possible errors

# Basic function structure:

# function_name <- function (argument/input variables) {
# statements/expression/equation          
#  }

# Call the function and evaluate


# Example 1 Write a function to find the volume of a cylinder

#  Volume = pi(r^2)h,  pi is approximately 3.14

volume_cylinder <- function(r, h) {
  pi*r^2*h
}

volume_cylinder(4, 6)
volume_cylinder(3, 10)

# Now lets add a descriptive statement for the output

# Example 2
volume_cylinder <- function(r, h) {
  V = pi*r^2*h
  print(paste("The volume of a cylinder with a radius of 4 and a height of 6 is",V))
  
}

volume_cylinder(4, 6)

# Now lets produce an answer that is rounded to a specified value

# Example 3
volume_cylinder <- function(r, h) {
  V = pi*r^2*h
  print(paste("The volume of a cylinder with a radius of 4 and a height of 6 is", 
              round(V, digits = 3)))
  
}

volume_cylinder(4, 6)


# Example 4

# function to print x raised to the power y
pow <- function(x, y) {
  result <- x^y
  print(paste(x,"raised to the power", y, "is", result))
}

pow(8, 2)
pow(2,8)
pow(x = 2, y = 8)
pow(y = 8, x = 2)
pow(x=8, 2)
pow(2, x = 8)
pow(y = 8, 2)
pow(2, y = 8)

pow <- function(x, y = 2) {
  # function to print x raised to the power y
  result <- x^y
  print(paste(x,"raised to the power", y, "is", result))
}

pow(5)

pow(5,3)  # overrides the default assignment


# Example 5a

# Write a function that will create the first 10 squares of positive odd integers. 
# That is your function will give you the following output.
# 1, 9, 25, 49, ., 361 when you input values 1 to 10.

# How do you write a positive odd integer?  2*x - 1 ,  where x is an integer


# Method 1

C <- function(x) {
  (2*x - 1)^2
}

C(1:10)


# Method 2
C <- function(x) {
  (2*x - 1)^2
  return((2*x - 1)^2)
} 

C(1:10)


# Example 5b

# Create a data frame
data_frame <- tibble(  
  c1 = rnorm(50, 5, 1.5), 
  c2 = rnorm(50, 5, 1.5),    
  c3 = rnorm(50, 5, 1.5),    
)
data_frame

# check
mean(data_frame$c1)
sd(data_frame$c1)

# Let's normalize over a column. The following would have to be done for each column,
#lets use column 1.


(data_frame$c1 - min(data_frame$c1)) / (max(data_frame$c1) - min(data_frame$c1))

# This is a tedious task, for we would need similar calculations for every element of all
# three columns

mean(data_frame$c1)
min(data_frame$c1)
max(data_frame$c1)
data_frame$c1


# We shall construct a function that will reduce the repetitive steps required.

# Assign expression to a variable for easier recognition and coding
data_frame$c1 -> x
x

normalize <- function(x){
  # step 1: create the nominator
  nominator <- x-min(x)
  # step 2: create the denominator
  denominator <- max(x)-min(x)
  # step 3: divide nominator by denominator
  normalize <- nominator/denominator
  # return the value
  return(normalize)
}
normalize(x)

# Using our function how could we get results for C2 ?



# The If else statement

#if (condition) {
#  Expr1 
#} else {
#  Expr2
#}


# Example 6

# Set the if-else statement
quantity <- 13  # indicate a quantity to process
if (quantity > 20) {
  print('You sold a lot!')
} else {
  print('Not enough for today')  
}

# Example 7  (Let's write a function that will test for divisibility)

# Is 125 divisible by 3?

# Method 1
x<-125
if (x %% 3 == 0) {
  print("the number is divisible by 3")
} else {
  print("the number is not divisible by 3")
}


# Method 2
FunctionA <- function(x)  
  if (x %% 3 == 0) {
    print("the number is divisible by 3")
  } else {
    print("the number is not divisible by 3")
  }

FunctionA(125)

FunctionA(2112)

# Multiple Conditions  / else if

# if
# else if
# else

# Example 8
# Write a function that will give a result for three conditions: x > 0, x < 0, 
# and x = 0.

check <- function(x) {
  if (x > 0) {
    result <- "Positive"
  }
  else if (x < 0) {
    result <- "Negative"
  }
  else {
    result <- "Zero"
  }
  return(result)
}

check(-3)
check(32)
check(0)


# Example 9

# Create vector quantity
quantity <-  26
# Create multiple condition statement
if (quantity <20) {
  print('Not enough for today')
} else if (quantity > 20  & quantity <= 30) {
  print('Average day')
} else {
  print('What a great day!')
}



# Using for loops

#For (i in vector) {
#   Exp	
#   }

# Example 1

for ( i in 1:4) {
  print (i^3)
}

# Example 2  values are not consecutively ordered

for (i in c(-2,4,7,-1)) {
  print (i^3)
}

# Example 3  

# Changing Kilometers to miles using a for loop

for (km in c(12,20,45,80,110)) {
  print(c(km, .621371*km))
}

q()
y

