

library(tidyverse)

read_csv("astronautsdata.csv") -> ad
ad


ad%>%
  select(Name, Gender, Status,`Military Rank`, `Space Flights`, 
         `Space Flight (hr)`) %>%
  filter(Gender == "Female") -> ad1
          ad1

          
ad%>%
  select(Name, Gender, `Space Flights`, `Space Flight (hr)`)%>%
  filter(Gender == "Female")-> ad2
  ad2
  
  as.data.frame(ad2)
  
  ggplot(data = ad2) +
    geom_boxplot(mapping = aes(y = `Space Flights`)) 
  
  ggplot(data = ad2) +
    geom_bar(mapping = aes(x= `Space Flights`)) 
  

  

  
  
  
  
  
  tribble(~Planet, ~Mass, ~Diameter, ~Density, ~Gravity, ~DayLength, ~MeanTemp, 
          ~DistfSun,
          "Mercury",.330, 4879, 5427, 3.7, 4222.6, 167, 57.9,
          "Venus",  4.87, 12104, 5243, 8.9, 2802, 464, 108.2,
          "Earth",  5.97, 12756, 5514, 9.8, 24, 15, 149.6, 
          "Mars",   .642, 6792, 3933, 3.7,  24.7,-65, 227.9,
          "Jupiter", 1898, 142984, 1326, 23.1, 9.9, -110, 778.6,
          "Saturn",   568, 120536, 687, 9.0, 10.7, -140, 1433.5,
          "Uranus",   86.8, 51118, 1271, 8.7, 17.2, -195, 2872.5,
          "Neptune",  102, 49528, 1638, 11.0, 16.1, -200, 4495.1,
          "Pluto",   .0146, 2370, 2095, .7, 153.3, -225, 5906.4) -> Planets
  Planets
  
  
  mean(Planets$Mass)
  max(Planets$Mass)
  sd(Planets$Mass)
  summary(Planets$Mass)
  
  
  Planets%>%
    summarize(Mean = mean(Mass))
  
  
  ggplot(data = Planets) +
    geom_boxplot(mapping = aes(y = MeanTemp))
  
  ggplot(data = Planets) +
    geom_freqpoly(mapping = aes(x = Mass))
  
  ggplot(data = Planets) +
    geom_bar(mapping = aes(x = Planet, y = Gravity, fill = Planet), 
             stat = "identity")
  
  ggplot(data = Planets) +
    geom_point(mapping = aes(x = DistfSun, y = MeanTemp))
  
  
  install.packages("plotrix")
  
  library(plotrix)
  Mass <- c( 1898, 568, 86.8, 102, .0146)
  Mass
  Planets1 <- c("Jupiter", "Saturn",
             "Uranus", "Neptune", "Pluto")
  Planets1
  
  pie3D(Mass,labels = Planets1, explode = .2, main = "3D Pie Chart")
  
  
diamonds

nrow(diamonds)
ncol(diamonds)



ggplot(data = diamonds) +
  geom_histogram(mapping = aes(x = carat), fill = "red")


ggplot(data = diamonds) +
  geom_boxplot(mapping = aes(x = cut, y = price, fill = cut))

q()
y
  