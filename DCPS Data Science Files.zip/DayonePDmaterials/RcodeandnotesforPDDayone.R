
# R Preliminaries

# INTRODUCTORY PROTOCOLS AND APPLICATIONS OF R CODING

# Basic Arithmetic Operations (Using R code)


# Multiply 12 by 2
12 * 2

# Note that the following construction does not work
# 12(2)   # multiplication has to be forced by using an asterik  *

# Add 12 to 2
12 + 2

# Subtract 2 from 12
12 - 2

# Divide 12 by 2
12/2


# 1 Raise 12 to the second power
12^2
12**2
# 2 Find the square root of 169.
169^.5

169**.5

sqrt(169)  

# 3 Raise  1/8 to the third power
(1/8)**3         
(1/8)^3
(1/8)*(1/8)*(1/8)

# 4 Evaluate 6 times the difference between between the square of 5 and 3.
6*(5^2 - 3)

# Note that you get an error if you try the following
#6(5^2 - 3)

# Logarithms

# 5 Evaluate log(1000)   (common log,  base 10)
log10(1000)   


# 6 Evaluate ln(1000)    (Natural log,  base e)
log(1000)

# Special irrational numbers

# Let's find the approximate value of e
exp(1)


#  Find the numerical approximation for pi.   (We should get  3.141593)
pi

# The natural log of e is 1.  Let's confirm this by using R code.

log(exp(1))

# Number Sequences

# 7 Write all integers 1 to 25 inclusive in ascending order
1:25

# 8 Write all integers 1 to 25 inclusive in descending order
25:1

# 9 Find the sum of all integers 1 to 25. 

sum(1:25)

# How can we write out all even integers that are >= 4 but <=22, using
# R code?


# 10 Find the mean of all integers 1 to 25. 

mean(1:25)

# 11 Find the median of all integers 1 to 25. 

median(1:25)

# 12 Find the mean, median, and other statistical indicators

summary(1:25)

# Using R code to round numbers

# 13 Round 7.2557 to the nearest tenth

round(7.2557, digits= 1)


# 14 Round 7.2557 to the nearest thousandths

round(7.2557, digits= 3)


# 16 Divide 1 by 7 and then round the answer to the nearest  hundredth 
# (use one line of code)

round((1/7),  digits = 2)


# Identifying R objects

# The most common types of of R objects that we will encounter are 
# characterized as numeric(double or integer), logical, or character.
# We can use the R command  typeof in order to characterize an object.


z = 5
z 

typeof(z)


k = 2.3
k
typeof(k)


t = FALSE
t

typeof(t)

u = "Boston"
u

typeof(u)

# or

typeof("Boston")



# Vectors and Lists

# What is a Vector ?

# In physics and mathematics a vector is a quantity or phenomenon 
# that has two independent properties; magnitude and direction. Our 
# definition or description however is considerably less technical.
# For the purposes of this class, a vector is simply a collection
# "things" or objects.  Those "things" can be numbers, words, letters, 
# or other miscellaneous items.

# Vectors are of two types:
#   Atomic Vectors
#   Lists
# Examples of Atomic Vectors (the objects are of the same type)

V1 <- c(12, 33, 2, 82, 33)  # All objects are integers

v2 <- c(.002, 3.6, 7.32, 4.5, 6.0) # All objects are doubles

V3 <- c(FALSE, TRUE, TRUE, FALSE)  # All objects are logical entries

V4 <- C("JANE", "BILL", "JUAN", "EILEEN", "ANN") # All objects are
# character strings

# Examples of Lists (objects can be of different types)

L1 <- list(6, 3.8, "every", TRUE)

L2 <- list(TRUE, 12, .0125, "cat", list(2:5)) # note that a list can
# contain another list

# Key Points

# There are six types of Atomic Vectors: logical, integer, double,
# character, complex, and raw.  Integer and double vectors are
# commonly referred to as numeric vectors.

# An Atomic Vector is homogeneous. (the items in the vector are
# of the same type)




#VECTOR  USAGE

# 18  Create a vector to find the mean of a set of numbers. 
#     Find the mean of 17 , 6, 10, 12
x <- c(7,6,10,12)
x

mean(x)


# 19  Create a vector to find the median of a set of numbers.  
#     Find the median of 17 , 6, 10, 12

x <- c(7,6,10,12)
x

median(x)


# 20   Create a vector to find the 1st and third quartile values of a set of numbers.  
# Find the 1st and 3rd quartile values of the numbers 17 , 6, 10, 12

x <- c(7,6,10,12)
x

summary(x)


# Using R to write a basic function 

# 21  Write a function  to find the area of a square.   ( A =  s^2)

A <- function(s)
{s^2
 return(s^2)
}
# Find the area of a square whose sides are 12 inches
  A(12)
# Suppose we want the areas of several squares
  A(c(12,10,8))


#22  Write a function to find simple interest   (I = prt)
  
  I <- function(p,r,t)
  {p*r*t
    return(p*r*t)
  }
# Find simple interest if $200 is invested at 5% for 2 years.
  I(200,.05, 2)
  
  
#23  Use R code to write a function that calculate a weighted average if 
     #  chapter exams account for 40% of your grade,
     #  homework accounts for 30% of your grade,  
     #  classwork accounts for 10% of your grade, and the final exam
     #  accounts for 20% of your grade.  
     #  (WA  = .40CE + .30HW  +  .10CW + .20FE)
  
WA <- function(CE,HW,CW,FE)
{.40*CE + .30*HW + .10*CW + .20*FE
  return(.40*CE + .30*HW + .10*CW + .20*FE)
}
# Now find the weighted average if a student has a chapter exam average of 80, 
# a homework average of 84, a classwork average of 76, 
# and a final exam score of 78.
WA(80,84,76,78)  

# Data Frames

# What is a data frame ?


# A data frame is the most common way of storing data in R and, generally it
# is the data structure most often used for data analyses.
# Under the hood, a data frame is a list of equal-length vectors. ... As a
# result, data frames can store different classes of objects 
# in each column (i.e. numeric, character, factor).

# The following structures are examples of Data Frames

#   Name Age Gender
#1  Bill  36  Male
#2  Anne  37  Female
#3 Frank  40  Male
#4  Mary  36  Female


mtcars


# Using R code to create a data frame.

# Example  Use R code to create the following data frame

#   Name Age Gender
#1  Bill  36  Male
#2  Anne  37  Female
#3 Frank  40  Male
#4  Mary  36  Female


# Solution

Name  <- c("Bill", "Anne", "Frank", "Mary")
Name
Age <- c(36, 37, 40, 36)
Age
Gender <- c("Male", "Female", "Male", "Female")
Gender

DF <- data.frame(Name, Age, Gender)
DF


# Finding statistical summaries and graphs for a variable of a data frame

# Note: we are using base R methods at this point for illustrative purposes
# (We will be using specific tidyverse procedures moving forward)


# Find the mean age of the data frame

mean(DF$Age)
#  Find the median age of the data frame

median(DF$Age)
#  Find  multiple statistical summary values for age

summary(DF$Age)
# Create a boxplot, a stem and leaf plot and a histogram for the 
# variable AGE of the data frame.

boxplot(DF$Age)


stem(DF$Age, scale = 2)


hist(DF$Age)




q()
y
