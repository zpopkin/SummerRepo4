
# Homework  Nultiple Regression  Key
library(tidyverse)

tribble(~EngineSize,  ~CurbWeight,  ~Horsepower,  ~MilesperGallon,
             2.4,         3289,          177,           24,
             2.4,         3263,          158,           25,
             2.5,         3230,          170,           24,
             3.5,         3580,          272,           22,
             2.8,         3175,          255,           18,
             3.5,         3643,          263,           22,
             3.5,         3497,          306,           20,
             3.0,         3340,          230,           21,
             3.6,         3861,          263,           19,
             2.4,         3287,          173,           24,
             3.3,         3629,          234,           21,
             2.5,         3270,          170,           22,
             3.5,         3292,          270,           22
        ) -> V
V
#1 Use and show R code that will produce a correlation matrix.
cor(V)

#2 Indicate if the correlation matrix shows multicollinearity problems with pairs of
# explanatory variables.  The variable MilesperGallon is the response variable

# Answer:  Engine Size and Horsepower are highly correlated.  Engine size and Curb Weight are
#          highley correlated.

#3 Indicate the explanatory variable(s) that the response variable is strongly correlated with.
# Answer:   The response variable MilesperGallon is strongly correlated with Horsepower.


#4 Use and show R code that will produce a full multiple regression model, that uses all 
#  explanatory variables. Write the full model that shows the coefficients for all explanatory
#  variables and the intercept.

lm(MilesperGallon~EngineSize + CurbWeight + Horsepower, data = V)

# Answer:   MilesperGallon = 4.803063EngineSize - 0.003945CurbWeight - 0.065831Horsepower   


#5 Use and show R code that will produce all important summary statistics for your model.

lm(MilesperGallon~EngineSize + CurbWeight + Horsepower, data = V)-> VV
VV
summary(VV)

#6 Which explanatory variable(s) is/are significant at the level of .05?

# Answer:  Horsepower

#7  Use your book or an internet source and describe the difference between R2 and adjusted R2.  
#   (four or five sentences)

#   Answer:  The primary difference between R-squared and the adjusted R-squared is that R-squared 
#            supposes that every independent variable in the model explains the variation in the 
#            dependent variable. It gives the proportion of explained variation as if all independent 
#            variables in the model affect the dependent variable, the adjusted R-squared, however,  
#            gives the proportion of variation explained by only those independent variables that in 
#            reality affect the dependent variable. 

#8 What is the proportion of the variability in Milespergallon that is explained by the
#  full model regression equation?
#  Answer:  .6257

#9 What is the proportion of the variability in Milespergallon that is explained by the
#  full model regression equation, only using explanatory variables that have significant
#  impact on the dependent variable.
#  Answer:   .5009

#10 Use and show R code that produces a model without the explanatory variable with the highest
#  p value. Write the new model that indicates the response variable, the explanatory coefficients
#  and the intercept.

lm(MilesperGallon~EngineSize + Horsepower, data = V)-> VVV
VVV
summary(VVV)

# Answer:  Miles per Gallon =  26.80495 + 2.14695 EngineSize - 0.05032 Horsepower

#11 Explain why the null hypothesis that the population coefficient for Engine Size is equal to
#   zero is not to be rejected.

# Answer:  In the summary table, the p value (.3410) for EngineSize coefficient is greater than .05. 
#          Hence we will fail to reject the null hypothesis.

# 12  Which model, the one with three explanatory variables or the one with two explanatory is the 
# better model for predicting Miles per gallon?  Justify your answer in three of four sentences.

# Answer:  The model with only two variables
#          (answers may vary) The p value for the two explanatory variable model has a lower p value
#          which indicates greater significance. .01277 compare to .02585 for the full model. The
#          usage of Curbweight did not add to the predictive power of your model.  Also the standard
#          errors for the two explanatory model are lower.

   

