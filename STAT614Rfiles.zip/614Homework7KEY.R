


#  STAT 614  HOMEWORK 7 Chapter 6 KEY

#1

#1a)
#  H(o):  mu = 501
#  H(a):  mu < 501
  
#1b)

# t statistic =  (ybar - mu)/ se,  se = s/sqrt(n) = 116/sqrt(1000 = 11.6
#             =  (485 - 501)/11.6
#             =   -1.3793

#  df = n-1 = 100 - 1 = 99

#1c)  Using the link provided in class;  p-value = .085501

#1d)  Since the p-value (.085501) is >.05, we fail to reject the null hypothesis H(O)


#2 
library(tidyverse)
mtcars
?mtcars

#2a   qsec is the  1/4 mile time

#2b
qqnorm(mtcars$qsec)  # the data points mostly line up, suggesting normality

#2c
hist(mtcars$qsec)    # the histogra strongly suggests normality

#2d
# Since both plots show moderate to strong patterns for normality, we can conclude that
# the assumption for normality is satisfied.

#2e

# H(o):  mu = 16
# H(a):  mu > 16

t.test(mtcars$qsec, mu = 16, alternative = "greater",  conf.level = .95)

# t statistic  5.8525   p-value  9.34e-07 or p-value = .000000934   
# 95% confidence interval   17.31315      Inf

# Since the p-value is less than .05 we will reject the null hypothesis  H(o)

# Since mu = 16 is outside of the confidence interval,  17.31315      Inf, we will
# reject the null hypothesis  H(o)

#3

#3a)  
prop.test(x = 75, n = 150, p = .45, alternative = "greater")  # p-value = .1253

#3b)
prop.test(x = 75, n = 150, p = .45, alternative = "less")  # p-value = .8747

#3c)
prop.test(x = 75, n = 150, p = .45, alternative = "two.sided")  # p-value = .2506

#3d)  All of these p-values are greater than .05, so none of them give strong evidence
#     against the null hypothesis H(o)


#4

#  H(o): pi = .65
#  H(a): pi > .65

prop.test(x = 297, n = 480, p = .65, alternative = "greater", conf.level = .95,
correct = FALSE)  # p-value = .9244   z statistic = sqrt(2.0604) = 1.4354   
# 95% confidence interval  0.5817162  1.0000000

# Since the p-value (.9244) > .05,  we fail to reject the null hypothesis H(o)


#5

#  H(o): mu = 2000
#  H(a): mu < 2000


# t statistic =  (ybar - mu)/ se,  se = s/sqrt(n) = 100/sqrt(10) = 31.6228
#             =  (1500 - 2000)/31.6228
#             =   -15.8114

#  df = n-1 = 10 - 1 = 9

#  Using the link provided in class; 
#  p-value link    https://www.danielsoper.com/statcalc/calculator.aspx?id=8 
#  p-value = .00001

#  Since the p-value (.00001) is <.05, we reject the null hypothesis H(O)

#  H(o): mu = 2000
#  H(a): mu > 2000

#  Same t statistic  -15.8114   p value is .99999.

#  Since the p-value (.99999) is >.05, we fail to reject the null hypothesis H(o)

q()
y




