
install.packages("rvest")
library(rvest)
library(dplyr)
library(tidyverse)
library(repurrrsive)
install.packages("listviewer")
listviewer::jsonedit(gh_users)


# RECTANGLING (Transforming a complicated list, called a nested list,
# into a data frame the is easier to interpret and process)

# Nested Lists -> lists withing a list.

# Here is a basic example that we studied previously
#  X = list(23, 3.01, "alpha", b = (100, 2.033, "rail", NA)). Note that we
# we have a list within a list. List b is nested in List X

# Our cases and examples will be more involved but the basic idea is the 
# same.

# Let's look at a nested list involving 6 Github users

(users <- tibble(user = gh_users))

# Lets take a look at the list data for each Github user

listviewer::jsonedit(gh_users)

# Now use the following code to print out the same information
# in the console

names(users$user[[1]])

# Now transform the nested data into a data frames

users %>%
  unnest_wider(user)
# Note that the characteristics have become column variables

users %>%
  unnest_longer(user)  # not a good representation.  The wider option
# is better.

# You may not want all of the column variables.  You can use the command
# hoist to select the variables and list content that you want.
users %>% hoist(user,
               followers = "followers",
               login = "login",
               url = "html_url")


# Game of Thrones

got_chars  # Lists regarding Game of Thrones characters that provides no 
# special structure or organization


# Let's organize the data into a tibble

chars <- tibble(char = got_chars)
chars

# And now look at the data Lets look at the specific data for the 30 names
listviewer::jsonedit(got_chars)   #1, #8, #17


# Now transform the nested data into a data frame

chars2 <- chars %>% unnest_wider(char)
chars2

# This is more complex than gh_users because some component of char are
# themselves a list, giving us a collection of list-columns:

chars2 %>% select_if(is.list)

# What you do next will depend on the purposes of the analysis. Maybe you 
# want a row for every book and TV series that the character appears in:

chars2 %>% 
  select(name, books, tvSeries) %>% 
  pivot_longer(c(books, tvSeries), names_to = "media", values_to = "value") %>% 
  unnest_longer(value)

# Or maybe you want to build a table that lets you match title to name:
  
chars2 %>% 
  select(name, title = titles) %>% 
  unnest_longer(title)


# WEB SCRAPING

Link <- "https://www.imdb.com/search/title/?genres=action&groups=top_250&sort=user_rating,desc"
page = read_html(Link)
Movienames = page%>% html_nodes(".lister-item-header a")%>%
html_text()
Movienames


Link <- "https://www.imdb.com/search/title/?genres=action&groups=top_250&sort=user_rating,desc"
page = read_html(Link)
years = page%>% html_nodes(".text-muted.unbold")%>%
  html_text()
years



Link <- "https://www.imdb.com/search/title/?genres=action&groups=top_250&sort=user_rating,desc"
page = read_html(Link)
Movieratings = page%>% html_nodes(".ratings-imdb-rating strong")%>%
  html_text()
Movieratings

# Let's organize our collected data onto a data frame.

moviesdataframe = data.frame(Movienames,years,Movieratings)
moviesdataframe

# Now let's improve the format and appearance of the data table by transforming
# into a tibble

is_tibble(moviesdataframe)


as_tibble(moviesdataframe)



# Washington DC

Link <- "https://forecast.weather.gov/MapClick.php?lat=38.897665087992735&lon=-77.0365505479276#.YE6yOp1KiUk"
page = read_html(Link)
Temperatures = page%>% html_nodes(".temp")%>%
  html_text()
Temperatures

# Let's only output the numbers
parse_number(Temperatures)

# Let's create plots and summaries for the collected data
parse_number(Temperatures) -> y
y

mean(y)
summary(y)
boxplot(y)


Link <- "https://forecast.weather.gov/MapClick.php?lat=38.897665087992735&lon=-77.0365505479276#.YE6yOp1KiUk"
page = read_html(Link)
DayNight = page%>% html_nodes(".period-name")%>%
  html_text()
DayNight


Weather = data.frame(DayNight, Temperatures)
Weather

# The data frame has a good structure/display. No need to change to
# a tibble.




q()
y
