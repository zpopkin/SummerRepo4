# Data Visualization ggplot practice (Tidyverse coding)
library(tidyverse)
mpg
#View(mpg)
#?mpg
# Lets create a boxplot (A plot that graphically displays outliers of a data distribution in
# addition to summaries such as Max, Min, Q1, Q3, and the Median)

ggplot(data = mpg) +
  geom_boxplot(mapping = aes(y=cty))

# We can also display a horizontal representation by using the coding coord_flip
ggplot(data = mpg) +
  geom_boxplot(mapping = aes(y=cty)) +
  coord_flip()


#Creating side by side boxplots (Show boxplots for highway mileage with respect to levels of a
# character variable)  We will use the character variable drv  (the type of drive train)

ggplot(data = mpg) +
  geom_boxplot(mapping = aes(x=drv, y=hwy)) 


# Lets create a histogram (A histogram is a graphical representation that organizes a group 
# of data points into user-specified ranges; shows the distribution of the data)
# )
ggplot(data = mpg) +
  geom_histogram(mapping = aes(x=cty))  #Tidyverse method

hist(mpg$cty)  #base R method


# Lets create a stem and leaf plot
stem(mpg$cty)  # base R method


# Bar Graphs !!


#Creating a basic bar graph using raw counts values of a data set.
#  (Tidyverse/ggplot method)  

#Let's create a bar graph from the mpg data table

mpg

ggplot(data = mpg) +
  geom_bar(mapping = aes(x = fl))  #Recall that the variable fl is an
# abbreviation for fuel type

# Change the x axis name to fuel type

ggplot(data = mpg) +
  geom_bar(mapping = aes(x = fl)) +
  xlab("fuel type")


# color the bars of the graphs

ggplot(data = mpg) +
  geom_bar(mapping = aes(x = fl, fill = fl))


# another bar graph
ggplot(data=mpg) +
  geom_bar(mapping = aes(drv))  # Recall that the variable drv is an abbreviation
# for drive train.


# Different Types of Bar Graphs

EmployeeInfo<- tribble(
  ~Name,  ~Gender,    ~Age,   ~PoliticalAffiliation, ~Salary,
  "Karen",   "Female", 32,        "Democrat",         63400,
  "Juan",   "Male",    42,        "Republican",       65000,
  "Alice",  "Female",  28,        "Democrat",         54500,
  "Robert", "Male",    32,        "Republican",       61200,
  "Fay",    "Female",  24,        "Independent",      66000,
  "Brian",  "Male",    30,        "Democrat",         72000,
  "Mary",   "Female",  25,        "Independent",      68000,
  "Anthony","Male",    32,        "Republican",       67000,
  "Aaron",  "Male",    27,        "Democrat",         67000
)

EmployeeInfo

#  A Bar Graph that shows counts of levels of a categorical variable
ggplot(data = EmployeeInfo) +
  geom_bar(mapping = aes(x = PoliticalAffiliation)) 

#  A Bar Graph that shows specific values for levels of a categorical variable
ggplot(data = EmployeeInfo) +
  geom_bar(mapping = aes(x = Name, y = Salary, fill = Name), stat = "identity")


# More Practice  Textbook problem.

# creating a bargraph using data with summary totals from created
#  data (Tidyverse Method)
library(tidyverse)

demo<-tribble(
  ~a,    ~b,
  "bar_1",  20,
  "bar_2",  30,
  "bar_3",  40
)

demo
# Now  create the bar graph  for created data.
ggplot (data = demo) +
  geom_bar(mapping = aes(x = a, y = b), stat = "identity") 


# Now create a colored bar graph
ggplot (data = demo) +
  geom_bar(mapping = aes(x = a, y = b ,fill = a), stat = "identity") 




# Lets create a scatter plot
plot(mpg$cty ~ mpg$hwy)   # base R method

ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy))   #Tidyverse method


#scatter plot  (change the color of the data points)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy), color = "red")

#scatter plot  (reflects patterns for different levels of a categorical variable)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy, color = trans))


#scatter plot (adding a title and axis labels to the graph)
ggplot(data = mpg) +
  geom_point(mapping = aes(x=cty, y=hwy)) +
 xlab("city") +
 ylab("highway") +
 ggtitle("milespergallon")
#scatter plot (adding a regression line to your plot)
ggplot(data=mpg) +
  geom_point(mapping = aes(x=cty, y=hwy)) +
  xlab("city") +
  ylab("highway") + 
  ggtitle("milespergallon") +
  geom_smooth(method=lm, mapping=aes(x=cty,y=hwy)) 


#scatter plot (Adding a line that follows the general path of the 
#scatter plot)

ggplot(data=mpg) +
  geom_point(mapping = aes(x = cty, y=hwy)) +
  geom_smooth(mapping = aes(x = cty, y=hwy))


#scatter plot (Producing smooth lines for a specified categorical
#variable)
ggplot(data=mpg) +
  geom_point(mapping = aes(x = displ, y=hwy)) +
  geom_smooth(mapping = aes(x = displ, y=hwy, color = drv))


# Lets create a Violin Plot for the variable hwy

# Note: a Violin plot conveys the distribution of the data in addition to the
# location of common summaries found in the corresponding boxplot.

ggplot(data=mpg) +
  geom_violin(mapping = aes(x = hwy, y = hwy)) 

# Now let's generate the violin plot along side the boxplot.
ggplot(data=mpg) +
  geom_violin(mapping = aes(x = hwy, y = hwy)) +
  geom_boxplot(mapping = aes(y = hwy)) +  
  coord_flip()

# Lets compare a violin Plot and a Boxplot for hwy

ggplot(data=mpg) +
  #geom_violin(mapping = aes(x = hwy, y = hwy)) +
  geom_boxplot(mapping = aes(y = hwy))


# Lets create a collection of Violin Plots for hwy over the character
# variable drv (drive train)

# for additional study of Violin Plots, access the link given below

ggplot(data=mpg) +
  geom_violin(mapping = aes(x = drv, y = hwy, fill = drv)) 


# Let's create pie charts !!


# Create data for the graph.
x <- c(21, 62, 10, 53)
labels <- c("London", "New York", "Singapore", "Mumbai")

# Plot the chart with title and rainbow color pallet.
pie(x, labels, main = "City pie chart", col = rainbow(length(x)))

#Now produce a pie chart that shows percentages
# Again, Create data for the graph.
x <-  c(21, 62, 10,53)
labels <-  c("London","New York","Singapore","Mumbai")


#Assign the percentage calculation to a variable
piepercent<- round(100*x/sum(x), 1)


# Plot the chart.
pie(x, labels = piepercent, main = "City pie chart",col = rainbow(length(x)))
legend("topright", c("London","New York","Singapore","Mumbai"), cex = 1,
       fill = rainbow(length(x)))


#Now let's create a 3D pie chart
# Install the package plotrix and also run the required library

#install.packages("plotrix")

library(plotrix)
Z <- c(21, 62, 10, 53)
Z

Cities <- c("London", "New York", "Singapore", "Mumbai")
Cities

pie3D(Z,labels = Cities, explode = .1, main = "3D Pie Chart ")


q()
y