

library(tidyverse)
library(dplyr)

read_csv("Covid19Data.csv") -> covid19
covid19

covid19%>%
  pivot_longer(col = "1/22/2020" : "10/15/2020", names_to = "date",
               values_to = "cases") -> covid19one
covid19one

print(covid19one, n = 25)

# 9

covid19one%>%
  filter(`Country/Region` == "Vietnam"|`Country/Region` == "Thailand" |
           `Country/Region` == "Singapore") -> covid19two
covid19two



library(tidyverse)
library(dplyr)


# 10

# Using the data table that you have developed for #9, answer the
# following questions and solve the following problems
View(covid19two)
# a) Use and show R code to find the date on which Singapore 
# experienced 12,693 cases (Code so that a data table shows
# relavant variables and the answer in the console) Indicate what
# the answer is.

covid19two%>%
  select(`Country/Region`, cases, date)%>%
  filter(cases == 12693, `Country/Region` == "Singapore")

# b) Use and show R code to find the maximum number of covid19
# cases experienced by the country of Thailand (Code so that a 
# data table shows relavant variables and the answer in the console)
# Indicate what the answer is.


covid19two%>%
  select(`Country/Region`, cases)%>%
  filter(`Country/Region` == "Thailand")%>%
  arrange(desc(cases))

# c) Use and show R code to find the total number of cases for
# all three countries together (Vietnam, Thailand, and Singapore).

sum(covid19two$cases)
  
# d) Use and show R code to find the total number of cases for
# each of the three countries (Vietnam, Thailand, and Singapore).
# Indicate what the answer is for each individual country.

covid19two%>%
  group_by(`Country/Region`)%>%
  summarise(Sumofcases = sum(cases))


















  
