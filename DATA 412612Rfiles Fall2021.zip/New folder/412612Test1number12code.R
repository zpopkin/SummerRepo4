

library(tidyverse)
library(dplyr)


midwest

ggplot(data = midwest) +
  geom_violin(mapping = aes(y = area, x = state, fill = state)) +
  ggtitle("Violin Plots (area vs state)") +
  coord_flip()



