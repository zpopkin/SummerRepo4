

x<- c(10,12,8,6)
x

mean(x)

x<- c(10,12,8,6, NA)
x
mean(x, na.rm = TRUE)

x[!is.na(x)] -> xx
xx
mean(xx)

y<- c(10,12,8,6, NA, na.rm = TRUE)
y

x <- c(1,2,NA,3)
x
mean(x) # returns NA
mean(x, na.rm=TRUE) 


mean(y)



q()
y