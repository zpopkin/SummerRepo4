
library(tidyverse)
library(tidyverse)


starwars

starwars%>%
  select(name,height, mass, species,gender) ->stw1
stw1

stw1%>%
  filter(species == "Human") -> stw2
stw2

stw2%>%
  arrange(desc(height))

ggplot(data = stw2) +
  geom_point(mapping = aes(x = height, y = mass), color = "red")

stw2%>%
  count(gender)

ggplot(data = stw2) + 
  geom_boxplot(mapping = aes(x = gender, y = mass), fill = "red")

# Using your boxplot (Do not use code), estimate Q3 for Humans who are feminine.

# Is Luke Sywalker Darth Vader's Father ?  Yes or No    

q()
y

