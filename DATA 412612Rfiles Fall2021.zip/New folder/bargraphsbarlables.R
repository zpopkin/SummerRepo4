



tribble(~Name, ~Gender,  ~Age, ~Gradelevel, ~Examone, ~Examtwo,
        "Leon", "Male",   18,      11,         72,      81,
        "Mary", "Female", 17,      12,         82,      86,
        "Alice","Female", 18,      11,         77,      83,
        "Matthew", "Male",16,      11,         86,      80
) -> StudentData
StudentData

ggplot(StudentData, aes(x = Name, y = Examone)) +
  geom_col(fill = "yellow") +
  geom_text(aes(label = Examone), vjust = 2, size = 5, color = "red")


ggplot(data = StudentData) +  
  geom_bar(mapping = aes(x = Name, y = Examone, fill = Name),
           stat = "identity") +
  geom_text(aes(x = Name, y = Examone, label = Examone), vjust = 2,
            size = 5, color = "red")