
library(tidyverse)
# Homework 5 KEY  problems 10 and 11

# 10

tribble (~Name,  ~Age, ~Department, ~YrsofSrvce, ~EduLevel, ~Salary,
         "Carlos", 30,  "Personnel",     4,          "MS", 71500,
         "Jacob",  26,  "Accounting",    6,          "BS", 70000,
         "Elaine",  31,    "IT",          4,          "BS", 75000,
         "Alice",  42,   "Sales",        5,          "BS", 72000,
         "Juan",   31,    "IT",          7,          "BS", 68000,
         "Ray",    28,  "Accounting",    5,          "MS", 81000,
         "Kate",   25,   "Sales",        4,          "BS", 74000,
         "Leon",   30,  "Personnel",    11,          "MS", 78000,
         "Robert", 29,  "Accounting",    8,          "MS", 77500
)-> EmployeeData
EmployeeData


#11

ggplot(data = EmployeeData) +  
  geom_bar(mapping = aes(x = Name, y = YrsofSrvce,fill = Name),
           stat = "identity") +
  geom_text(aes(x = Name, y = YrsofSrvce,label = YrsofSrvce), vjust = 2,
            size = 3, color = "black") +
  ggtitle("Years of Service Bar Graph")
  
  
  



