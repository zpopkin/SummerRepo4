
library(tidyverse)
library(dplyr)

tribble (~Name,  ~Age, ~Department, ~YrsofSrvce, ~EduLevel, ~Salary,
         "Brandi", 27,  "IT",            9,          "BS", 67500,
         "Carlos", 30,  "Personnel",     4,          "MS", 71500,
         "Jacob",  26,  "Accounting",    6,          "BS", 70000,
        "Elaine",  31,    "IT",          4,          "BS", 75000,
         "Alice",  42,   "Sales",        5,          "BS", 72000,
         "Juan",   31,    "IT",          7,          "BS", 68000,
         "Ray",    28,  "Accounting",    5,          "MS", 81000,
         "Kate",   25,   "Sales",        4,          "BS", 74000,
         "Leon",   30,  "Personnel",    11,          "MS", 78000,
         "Robert", 29,  "Accounting",    8,          "MS", 77500
)-> EmployeeData
EmployeeData

# 1 Add the following information to your EmployeeData table for the
# employee Brandi:  she is 27 years old, she works in the IT department,
# she has worked for the company for 9 years, she has a BS degree, and
# she has a Salary of 67,500 dollars.

#2 Use R code to find the mean for the Salary values.

# Data Visualization

# 3 Produce a boxplot for the variable Salary (use ggplot coding)

ggplot(data = EmployeeData) +
  geom_boxplot(mapping = aes(y = Salary))


# 4 Create a boxplot for the variable Age that is colored yellow and
# is oriented horizontally

ggplot(data = EmployeeData) +
  geom_boxplot(mapping = aes(x = Age), fill = "Yellow")


# 5 Create side by side boxplots for each level of the variable
# Educational Level (EduLevel) for the quantitative variable Salary

ggplot(data = EmployeeData) +
  geom_boxplot(mapping = aes(y = Salary, x = EduLevel,
  fill = EduLevel))


# 6 Create a scatterplot to explore a relationship between Years of 
# service and Salary.  Let Years of Service be independent (x) and
# let Salary by (y).
 
ggplot(data = EmployeeData) +
  geom_point(mapping = aes(x = YrsofSrvce, y = Salary ))

# 7 Use piping and a dplyr function to modify your table so that it
# only shows observational rows for employees who have a BS degree.

EmployeeData%>%
  filter(EduLevel == "BS")


# 8 Use piping and a dplyr functions to only select variables Name, Age,
# and Salary, show employees who are less than 30 years old that have
# a salary that is greater than or equal to 70000 dollars. Finally, 
# add code that will sequence Salary in descending order.

# Your output should show that only four employees fall in this
# category.

EmployeeData%>%
  select(Name, Age, Salary) %>%
  filter(Age < 30, Salary >= 70000)%>%
  arrange(desc(Salary))



q()
y
